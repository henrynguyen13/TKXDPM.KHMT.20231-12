packageSearchIndex = [{
    "l": "All Packages",
    "u": "allpackages-index.html"
}, {"l": "common.exception"}, {"l": "controller"}, {"l": "entity.cart"}, {"l": "entity.db"}, {"l": "entity.invoice"}, {"l": "entity.media"}, {"l": "entity.order"}, {"l": "entity.payment"}, {"l": "entity.shipping"}, {"l": "entity.user"}, {"l": "subsystem"}, {"l": "subsystem.interbank"}, {"l": "utils"}, {"l": "views.screen"}, {"l": "views.screen.cart"}, {"l": "views.screen.home"}, {"l": "views.screen.invoice"}, {"l": "views.screen.payment"}, {"l": "views.screen.popup"}, {"l": "views.screen.shipping"}];
updateSearchResults();